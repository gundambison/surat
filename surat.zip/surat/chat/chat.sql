-- phpMyAdmin SQL Dump
-- version 3.5.2.2
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Jan 31, 2016 at 06:00 AM
-- Server version: 5.5.27
-- PHP Version: 5.6.17

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `chat`
--

-- --------------------------------------------------------

--
-- Table structure for table `last_seen`
--

CREATE TABLE IF NOT EXISTS `last_seen` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `message_id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `messages`
--

CREATE TABLE IF NOT EXISTS `messages` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `from` int(11) NOT NULL,
  `to` int(11) NOT NULL,
  `message` text NOT NULL,
  `is_read` enum('0','1') NOT NULL DEFAULT '0',
  `time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE IF NOT EXISTS `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `firstname` varchar(255) NOT NULL,
  `lastname` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `username` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `avatar` varchar(255) NOT NULL,
  `online` enum('1','0') NOT NULL DEFAULT '1',
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=7 ;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `firstname`, `lastname`, `email`, `username`, `password`, `avatar`, `online`, `created_at`, `updated_at`) VALUES
(1, 'pabean', 'bcbontang', 'bcbontang@bcbontang.com', 'pabean', 'def5d6ac3989fb090e680a9fcc4dbeecb8496e4b', '', '0', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(2, 'umum', 'bcbontang', 'bcbontang2@bcbontang.com', 'umum', 'b617726c7f45ecb196ef74881089fa17d90d7276', '', '1', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(3, 'perben', 'bcbontang', 'bcbontang3@bcbontang.com', 'perben', '2990e3f0978d1122dd2a6017a2d0dd16de619d12', '', '1', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(4, 'kip', 'bcbontang', 'bcbontang4@bcbontang.com', 'kipbcbontang', '07d51e272055fb61c047ca12bcbcb79e3543ce70', '', '0', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(5, 'p2', 'bcbontang', 'bcbontang5@bcbontang.com', 'p2bcbontang', '4e580249e100c1f87db82e6ff1333c33d4d5da54', '', '1', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(6, 'kk', 'bcbontang', '1@bcbontang.com', 'kkbcbontang', 'ce1d2fc6dae8797f0054f419b33cf60f464beac2', '', '1', '0000-00-00 00:00:00', '0000-00-00 00:00:00');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
